import java.util.*;

public class Main {

    public static List<List<String>> solveNQueens(int n) {
        // write your code here
    }

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int n = scn.nextInt();
        List<List<String>> res = solveNQueens(n);
        System.out.println(res);
    }

}